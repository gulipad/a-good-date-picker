"use client";

import { ThemeToggle } from "@/components/theme-toggle";
import { useState } from "react";
import { DatePickerWithPresets } from "@/components/ui/date-picker";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism";
import { datePickerCode } from "@/lib/code-examples";
import { ClipboardIcon, CheckIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Home() {
  const [activeTab, setActiveTab] = useState<"preview" | "code">("preview");
  const [hasCopied, setHasCopied] = useState(false);

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(datePickerCode);
    setHasCopied(true);
    setTimeout(() => setHasCopied(false), 2000);
  };

  return (
    <div className="min-h-screen flex flex-col items-center p-8 relative">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>
      <main className="max-w-4xl w-full space-y-8">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold tracking-tight">
            A good date picker
          </h1>
          <p className="text-lg text-muted-foreground">
            Because picking dates should not take more than two clicks.
          </p>
        </div>

        <div className="space-y-4">
          <nav className="flex border-b">
            <button
              onClick={() => setActiveTab("preview")}
              className={`px-4 pb-3 pt-2 -mb-px text-sm font-medium ${
                activeTab === "preview"
                  ? "border-b-2 border-primary"
                  : "text-muted-foreground"
              }`}
            >
              Preview
            </button>
            <button
              onClick={() => setActiveTab("code")}
              className={`px-4 pb-3 pt-2 -mb-px text-sm font-medium ${
                activeTab === "code"
                  ? "border-b-2 border-primary"
                  : "text-muted-foreground"
              }`}
            >
              Code
            </button>
          </nav>

          <div className="rounded-lg border">
            {activeTab === "preview" && (
              <div className="p-6">
                <div className="flex min-h-[400px] items-center justify-center">
                  <DatePickerWithPresets />
                </div>
              </div>
            )}
            {activeTab === "code" && (
              <div className="p-0 max-h-[400px] overflow-auto rounded-lg relative">
                <div className="sticky top-0 z-10 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
                  <div className="absolute right-4 top-4">
                    <button
                      onClick={copyToClipboard}
                      className={cn(
                        "p-2 rounded-lg transition-colors duration-200",
                        "bg-muted/80 hover:bg-muted"
                      )}
                    >
                      {hasCopied ? (
                        <CheckIcon className="h-4 w-4 text-green-500" />
                      ) : (
                        <ClipboardIcon className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>
                <SyntaxHighlighter
                  language="typescript"
                  style={oneDark}
                  customStyle={{
                    margin: 0,
                    fontSize: "14px",
                  }}
                >
                  {datePickerCode}
                </SyntaxHighlighter>
              </div>
            )}
          </div>
        </div>
      </main>
      <footer className="fixed bottom-0 w-full p-4 text-center text-sm text-muted-foreground">
        Made with ❤️ by{" "}
        <a
          href="https://gulipad.com"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:underline font-medium"
        >
          Gulipad
        </a>
      </footer>
    </div>
  );
}
